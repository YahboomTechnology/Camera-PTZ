#include "ti_msp_dl_config.h"
#include "bsp_delay.h"
#include "bsp_usart.h"
#include "stdio.h"
#include "bsp_servo.h"

//������
int main(void)
{
	uint8_t i=0;
	uint16_t j=0;
	SYSCFG_DL_init();

 //��������жϱ�־
	NVIC_ClearPendingIRQ(MYUART_INST_INT_IRQN);
	//ʹ�ܴ����ж�
	NVIC_EnableIRQ(MYUART_INST_INT_IRQN);
	
	
	DL_TimerA_startCounter(PWM_Servo_INST);//�������ƶ����ʱ��
	
	Set_Servo_Angle(90); //180
	Set_Servo270_Angle(135);//270
	
	delay_ms(300);

	while (1) 
	{    
		
		  Set_Servo_Angle(i++); //180
			Set_Servo270_Angle(j++);//270
			if( i >= 180 )   
			{
					i = 0;
			}
			if( j >= 270 )   
			{
					j = 0;
			}
				
       delay_ms(150); 
		 
	}
} 



